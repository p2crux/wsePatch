#!/bin/bash

OS=$1
INST_DIR=$2

chmod +x $INST_DIR/lib/wms-server.jar

if [ "$OS" = "linux" ]
then
	find -L $INST_DIR -type f | grep -v wms-server.jar | xargs -I {} chmod --reference $INST_DIR/lib/wms-server.jar "{}"
	find -L $INST_DIR -type f | grep -v wms-server.jar | xargs -I {} chown --reference $INST_DIR/lib/wms-server.jar "{}"
else
	MODE=`stat -f "%p" "$INST_DIR/lib/wms-server.jar"`
	OWNER=`stat -f "%u:%g" "$INST_DIR/lib/wms-server.jar"`
	find -L $INST_DIR -type f | grep -v wms-server.jar | xargs -I {} chmod $MODE "{}"
	find -L $INST_DIR -type f | grep -v wms-server.jar | xargs -I {} chown $OWNER "{}"
fi
