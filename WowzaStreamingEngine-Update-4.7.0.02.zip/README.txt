Changes in Wowza Streaming Engine 4.7.0.02 Build 20446
========================================

   * Added H264 WebRTC constraints override properties. These should only be used when WebRTC is being used
      * Added Application/RTP property rtpForceH264Constraint (Boolean, default=false) to override the constraints value for H264
      * Added Application/RTP property rtpForceH264ConstraintValue (Integer, default=192) to set the override constraint value. Only the top 4 bits MUST be set
   * Improved RTSP/RTP playback to properly handle Streams/Properties instanceOn and instantOnBufferTime
   * Fixes several issues with PushPublishManager API interaction with PushPublish module in the area of adding and deleting targets
   * Fixed bad xml in Akamai DASH manifest for audio AdaptionSet with DRM
   * Added default Sample Frequency (8000) for PCM audio when creating SDP entries
   * Fixed Application/RTP property rtpForceH264Constraint so it can be set independently to rtpUseLowestH264Constraint and rtpUseHighestH264Constraint
   * Fixed destination stream name generation for wowza-cdn stream targets to follow [stream_name]_1_[bitrate] format as is used for wowza-streaming-cloud targets
   * Added MediaCaster/Properties property streamForceResetOnReconnect (boolean default = false) to force a complete unpublish/republish of a stream when a liverepeater connection is reset
   * Fixed LiveStreamRecord synchronization to prevent segmentation failing
   * Fixed issue with incorrect generation of destination stream names for wowza-streaming-cloud and wowza-cdn stream targets
   
Changes in Wowza Streaming Engine 4.7.0.01 Build 20312
========================================

   * Fixed nDVR Converter REST swagger documentation to include the dvrConverterStoreList parameter, which is required by the DvrRESTConverterStoresAction API
   * Fixed nDVR Converter API so that it honors the dvrConverterDefaultFileDestination parameter
   * Fixed nDVR 404 playlist responses so they include CORS headers
   * Fixed WSEM where we showed "not supported when Only DVR Streaming is enabled" for the MPEG DASH playback type (on app Setup tab) any time when "DVR streaming only" is selected in nDVR config, even when nDVR is disabled
   * Added Application/Properties property liveStreamRecorderDebugAACTimecodes (Boolean, default=false) than enables debugging of AAC timecodes when recording to a file
   * Added Application/RTP property resyncAudioVideoOnSRLogStreamSuffix (String, default not used) that allows timecodes from transcoded streams to be logged when resyncAudioVideoOnSRLog is enabled 
   * Added H264 WebRTC constraints properties. These should only be used when WebRTC is being used
      * Added Application/RTP property rtpUseLowestH264Constraint (Boolean, default=false) to force the use of the lowest constraint information found in a H264 video stream
      * Added Application/RTP property rtpUseHighestH264Constraint (Boolean, default=false) to force the use of the highest constraint information found in a H264 video stream
   * Fixed SCTE parsing to correctly return splice information
   * Added query parameter dvrConverterInterleaveDelay to the nDVR REST API for store conversions to control IO saturation time
   * Fixed Stream Targets PushPublishHTTPCupertino base class so that after a media segment is pushed, the actual chunk object reference that is held by the associated MediaSegmentModel is cleared, instead of just the chunk's fragments list
   * Fixed HTTP stream target profiles (for HLS, HDS & DASH) so that they do not ABR groups as being "ready" until they have a populated chunklist, avoiding the "Failed to create group playlist for group..." log that would appear at the beginning of the ABR push session(s)
   * Added IWebSocketEventNotify2.onIdle(IWebSocketSession webSocketSession) handler to websocket event interface to enable hooking into idle events
   * Improved liverepeater-lowlatency stream type to properly set low-latency stream settings
   * Added live stream receiver log statement on stream startup to log additional information about live stream settings such as sort buffer and onFlushNotifyClient
   * Improved error handling for HTTPSByteWriter to avoid exceptions when hostname/remote servers are not available
   * Fixed AppleHLS mediacaster fetch timers so they do not over compensate when large delays occur
   * Fixed AppleHLS mediacaster retry logic to correctly retry within the limits defined
   * Fixed AppleHLS mediacaster when playlist retrieval results in an unparseable response
   * Fixed nDVR conversion for audio only streams when using a start offset
   * Improved REST API nDVR endpoint to report when a conversion is already in progress
   * Fixed Wowza Streaming Engine Manager so that errors that occur while deleting Wowza CDN stream targets get properly handled and report a failure message to the Stream Targets page
   * Fixed Server Name Identification (SNI) configuration so that variable expansion works properly on the <DomainToKeyStoreMapPath> field in the host port SSL config as well as the "keyStorePath" field in DomainToKeyStoreMap.txt
   * Improved nDVR store error handling when invalid data is encountered
   * Updated streamfiles/{streamfileName}/adv endpoint changing RTPTransportMode to interleave to match default Application.xml configuration
   * Fixed PushPublishHTTPCupertino base class so that when a disconnect() occurs when the target has no playlist/chunklist built yet, it does not trigger an NPE
   * Updated LiveRepeater MediaCaster to unpublish/republish when forceReset is called using the reconnectWaitTime parameter
   * Fixed bug where an Application shutdown request via REST or JMX interface occurring at the same time as an HTTP session timeout-shutdown could cause a deadlock
   * Fixed H264 MediaReader to correctly count atom entries to allow playback for f4v files
   * Fixed bug in REST where vhost name was being handled incorrectly; introduced in 4.7.0.01 Build 20252
   * Fixed Akamai HLS/HDS/DASH stream targets to properly handle relative playlists when an eventName is defined for the target
   
========================================
